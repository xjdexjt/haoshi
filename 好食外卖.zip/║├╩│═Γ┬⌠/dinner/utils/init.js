var Bmob = require('bmob.js');
Bmob.initialize("51e4ad17b068a74cd59ac0be8267c824", "f0fe9d810e6141d257587af03a5dffea");